<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="GET">
	<input type="text" name="person">
	<input type="submit" name="submit">
</form>
<?php 
$name=$_GET['person'];
echo $name." "."is trying his best";

// array in php
$a1 = array("zual",'1',"sahil");
echo $a[1];
 ?>
</body>
</html>