<!DOCTYPE html>
<html>
<head>
	<title>INDEX PAGE</title>
</head>
<body>

 <?php 
require'navbar2.php';
echo "<br>";
?>
<div class="row" style="margin:0px 0px 10px 600px;">
 	<div class="col-lg-4" style="color:black;background:#ff8533;text-align: center;border-radius:5px;font-size: 20px;font-family: cursive;">
 		


<?php  

if (isset($_SESSION['userUid'])) {
	echo '<p>You are logged in!</p>';
	require 'main.php';
}
else
{
	echo '<p>You are logged out!</p>';
	echo "<br> <hr>";
	echo "To access the website you need to login first.";
}
 ?>
 </div>
 </div>

<?php require'footer.html' ?>

</body>
</html>