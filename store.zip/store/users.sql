-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2020 at 05:40 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitnessworld`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL,
  `uidUsers` tinytext NOT NULL,
  `emailUsers` tinytext NOT NULL,
  `pwdUsers` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idUsers`, `uidUsers`, `emailUsers`, `pwdUsers`) VALUES
(6, 'zual1', 'zual@gmail.com', '$2y$10$oBmMqFCwWywXWh0Zkmra3Ovpo2bfV7r6Q1s5ljW0ZkfQ1gUzfID7G'),
(7, 'ahmed', 'ahmed@gmail.com', '$2y$10$rVROd9.SRhYs7B9KK7Qbsel80C2vpzdF4qSUqr7GppTMXcGGNsXHy'),
(8, 'abc', 'sbc@hjy.com', '$2y$10$fYLFgYEVH5TL53ybpp41XuREhrAMtWCVAGPyGEkKhe6fR7GK8MV12'),
(9, 'new', 'new@gmail.com', '$2y$10$uWrJC8NsPo3wSKdpo6./7O8e5S.FjF4z61z1Aphnui71OX3zejVCi'),
(10, 'new2', 'new2@hotmail.com', '$2y$10$2ssXk75oDAm8TUrulomO5uQ7Euqy48dnVSvzR9X3qzN9p.vbSuGm6'),
(11, 'new3', 'n@hm.com', '$2y$10$n7fiocRieBUXudMPfoWoVOpV0aF6ildODGMPQfHTHVbXBdR/exvNm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUsers`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `idUsers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
