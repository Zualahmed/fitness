
 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 	<title>Fitness world</title>
 	
 </head>


 <body>
 
 	<div class="container-fluid" style="background: #BED2FB">

 		<!-- nav bar -->

 
<?php 

require'navbar.php';
?>
 <div class="row" style="margin:0px 0px 10px 600px;">
 	<div class="col-lg-4" style="color:black;background:#ff8533;text-align: center;border-radius:5px;font-size: 20px;font-family: cursive;">
 		<?php  

if (isset($_SESSION['userUid'])) {
	echo '<p>You are logged in!</p>';
	
}
else
{
	echo '<p>You are logged out!</p>';
	
}
	?>
</div>
</div>


 

  <!--slideahow  -->

  <div class="row">
 	<div class="col-lg-12">
 		<?php 
require'slideshow.html'
  ?>

 	</div>
 </div>
 
             <!-- authenticity logo-->
 <div class="row">
 	<div class="col-lg-6"><img src="img/on img.jpg" style="width: 100%;"></div>
 	<div class="col-lg-6"><img src="img/auth_new.gif" style="padding:20px 0px 0px 200px"></div>
 </div>

 <!-- options  -->

<div class="row">
	<div class="col-lg-12">
		 <h2 class="h">Hi, what are you looking for?</h2>
      </div>

</div>
<br>

<div class="row">
	<div class="col-md-2"><img src="img/ayurveda.jpg">
		<p style="color: #011744;font-size: 17px">AYURVEDA</p></div>
	<div class="col-lg-2"><img src="img/fitness.jpg">
	<p style="color: #011744;font-size: 17px">FITNESS</p></div>
	<div class="col-lg-2"><img src="img/health.jpg">
	<p style="color: #011744;font-size: 17px">HEALTH</p></div>
	<div class="col-lg-2"><img src="img/vitamins.jpg">
		<p style="color: #011744;font-size: 17px">VITAMINS</p></div>
	<div class="col-lg-2"><img src="img/wellness.jpg">
		<p style="color: #011744;font-size: 17px">WELLNESS</p></div>
	<div class="col-lg-2"><img src="img/sports and nutrition.jpg">
	<p style="color: #011744;font-size: 17px">SPORTS NUTRITION</p></div>
</div>
<br>

<!-- ayurvedic products -->
<?php 
require'ayurvedic.php'
 ?>

<!-- vitamins product -->

<?php 
require'vitamins.php'
 ?>

<!-- spots products -->
<?php 
require'sportsnutrition.php'
 ?>
<br>
<div class="row" style="border:1px solid black;">
	<div class="col-lg-6">
		<img src="img/new2.jpg" style="height: 170px; width: auto;">
		
	</div>
	<div class="col-lg-6">
		<h3 style="margin-top: 20px; color: white;"><ul><b>Earn FW Cash</b></ul> </h3>
		<h4 style="margin-top: 50px; color: green;">Shop with us and get FW Cash to redeem on your next purchase.</h4>
	</div>
</div>

<div class="row">
	<div class="col-lg-12"><h3 style="color: green"><b>WE WORK IN COLLABORATION WITH</b></h3></div>
</div>

<div class="row">
	<div class="col-lg-3"><img src="img/on.jpg"></div>
		<div class="col-lg-3"><img src="img/isopure.jpg"></div>
			<div class="col-lg-3"><img src="img/mb.jpg"></div>
				<div class="col-lg-3"><img src="img/roniecole.jpg"></div>
</div>

<div class="row">
	<div class="col-lg-3"><img src="img/ssn.jpg"></div>
		<div class="col-lg-3"><img src="img/ultimateNutrition.jpg"></div>
			<div class="col-lg-3"><img src="img/universal.jpg"></div>
				<div class="col-lg-3"><img src="img/muscleTech.jpg"></div>
</div>
<hr>


<div class="row">
	<div class="col-lg-12"><h3><b>WHY FITNESS WORLD</b></h3></div>
</div>


<div class="row" style="background:#ECADA3;border: 1px  solid #062047">
	<div class="col-lg-6" ><p><b>Approximately 80-90% of the supplements sold in India are imported from developed countries, like US and Europe. There is 70% customs duty on these products, which means that for a legitimate product, the retail price would be almost twice that of the retail price in developed countries.Heavy customs duty attracts large amounts of parallel or unethical imports. Given that these products have been illegally imported into the country, sourcing information is not available and quality becomes a question. Because of the supplements being highly priced and customers' inability to differentiate a legitimate product from a regular powder, several opportunistic resellers create and sell fake products in the market. Fake products look very similar to their original counterparts and are typically mixed with parallel-imported supplements.</b></p></div>
	<div class="col-lg-6"><p><b>It means that if you are buying a non-authorised product, you may be lucky and get an authentic product, but 1 out of 5 people will likely get a fake product, which may contain banned substances, such as steroids, and get you on a risk of causing permanent damage to your body.At HealthKart, we strive to provide 100% authentic products to our customers and we achieve this goal by maintaining:</b></p></div>
</div>

<div class="row">
	<div class="col-lg-12"><h4> You can pay using</h4></div>
</div>
<div class="row">
	<div class="col-lg-1">
		<div class="thumbnail">
			<div class="caption">
			<img src="img/americanexpress.jpg" style="width: 70px;height: auto;"></div>
			
				<h4>american express</h4>
			</div>
		</div>

	<div class="col-lg-1">
		<div class="thumbnail">
			<div class="caption">
			     <img src="img/mastercard.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>Master Card</h4>
		</div>
	</div>
	<div class="col-lg-1"><div class="thumbnail">
			<div class="caption">
			     <img src="img/mobikwik.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>Mobikwik</h4>
		</div></div>
	<div class="col-lg-1"><div class="thumbnail">
			<div class="caption">
			     <img src="img/netbanking.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>Internet banking</h4>
		</div></div>
	<div class="col-lg-1"><div class="thumbnail">
			<div class="caption">
			     <img src="img/paytm.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>Paytm</h4>
		</div></div>
	<div class="col-lg-1"><div class="thumbnail">
			<div class="caption">
			     <img src="img/cashondelivery.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>COD</h4>
		</div></div>
	<div class="col-lg-1"><div class="thumbnail">
			<div class="caption">
			     <img src="img/freecharge.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>Freecharge</h4>
		</div></div>
	<div class="col-lg-1"><div class="thumbnail">
			<div class="caption">
			     <img src="img/visa.jpg" style="width: 70px;height: auto;">
		    </div>
			
				<h4>Visa</h4>
		</div></div>
	
</div>
<?php require'footer.html' ?>



</div>	
  


</body>
 </html>
