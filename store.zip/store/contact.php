<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>contact us</title>
</head>
<body>
	
		<div class="container-fluid" style="background: #B8F28D">
			<?php require'navbar.php' ?>
		<div class="row">
			<div class="col-lg-12"><h3 style="text-align: center;"><b>Contact us</b></h3></div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<p style="font-size: 22px;">Have a query??</p> <hr>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
			    <p style="font-size: 19px;">Before you contact us please do have a look at our <e>FAQS</e> for a quicker resolution of your query.</p>
			</div>
		</div> 
		<div class="row">
			<div class="col-lg-12" style="border:1px solid black;">
				<p style="font-size: 20px;color: blue;border-bottom: 1px solid black;padding-bottom: 5px;">Order related FAQS</p>
				
				<select type="dropdown">
					<option type="selected">What do the different order status mean?</option>
					<option>Payment Pending Authorization: <br> Your order has been logged and we are waiting for authorization from the payment gateway.</option>

 <option>Payment Authorized, Order under Processing:<br> Authorization has been received from the payment gateway and your order is being processed by the seller.</option>

<option><b>COD Verification Pending:</b> Your order has been received by us but is processed only after a verification call if made to your number and you verify the COD order.</option>

<option><b>Order Shipped:</b> Your order has been shipped by the seller and is on its way to the location specified by you for delivery.</option>

<option><b>Order Cancelled:</b> The order was cancelled. </option>
				</select>
				<br><br>

				<select type="dropdown" style="color: blue;">
					<option type="selected"> How do i know my order has been confirmed?</option>
					<option>Once your order has been logged and payment authorization has been received, the seller confirms receipt of the order and begins processing it.</option>
					<option>You will receive an email containing the details of your order when the seller receives it and confirms the same.</option>
					<option> In this mail you will be provided with a unique Order ID, a listing of the item(s) you have ordered and the expected dispatch or delivery time.</option>
					<option>You will also be notified when the item(s) are shipped to you. Shipping details will be provided with the respective tracking number(s).</option>
				</select>
				<br><br>
				<select type="dropdown">
					<option>Can i order a product that is 'Sold Out'?</option>
					<option>Unfortunately, products listed as 'Sold Out' are not available for sale. Please use the 'Notify Me' feature to be informed of the product's availability.</option>
					
				</select> <br><br>
				<select type="dropdown" style="color: blue;">
					<option>How do i check current status of my orders?</option>
					<option>You can review the status of your orders and other related information in the 'My Account' section</option>

<option>In the My Account page, click on the 'My Orders' link to view the status of all your orders. To view the status of a specific order, click on the 'Order Number' link.</option>
				</select>
				<br><br>
			</div>
		
		</div>
		<br><br>
		<div class="row" style="border: 1px solid black;">
			<div class="col-lg-12" style="font-size: 20px;color: blue;border-bottom: 1px solid black;padding-bottom: 5px;" >Payment related FAQs</div>
			<select>
				<option>How do I pay for fitness world purchase</option>
				<option>There are zero hidden charges when you make a purchase on HealthKart.</option>
				<option>The prices listed for all the items are final and all-inclusive. The price you see on the product page is exactly what you pay.</option>

            <option>You may use Credit cards/Debit cards, Internet Banking and Cash on Delivery to make your purchase.</option>
			</select>
            <br><br>
			<select>
			<option>Are there any hidden charges when i make a purchase on fitness world </option>
			<option>There are zero hidden charges when you make a purchase on HealthKart.</option>
			<option>The prices listed for all the items are final and all-inclusive.</option>
			<option>The price you see on the product page is exactly what you pay</option>
	<option>You would be charged Rs 30 delivery charges if your order is less than Rs 500</option>
<option>Also a Rs 30 COD charges are applicable if your COD purchase is less than Rs 500.</option>
		</select>
		</div> 
		<br><br>
		<div class="row">
			<div class="col-lg-12">
				<h3 style="color: red;">Reach us</h3><hr>
				<p><b>Call us </b>- 8638014397      Monday to Saturday from 10 AM to 7 PM</p><br>
				<p><b>Email us</b>- zualahmed@gmail.com</p>
			</div>
		</div>
		

<?php require'footer.html' ?>






</div>
	

</body>
</html>