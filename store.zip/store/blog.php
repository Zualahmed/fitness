 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 	<title>Blog page</title>
 </head>
 <body>
 	<div class="fluid-container" style="background: #E0E5E7">
 		<div>
 			<?php 
              require'navbar.php';
 			 ?>
 		</div>

 		<div>
 			<?php 
             require'blogslideshow.html';
 			 ?>
 		</div>
 		<!-- recepie -->
 		
 		<div class="row">
 			<div class="col-lg-12" style="text-align: center;font-size: 40px;color: #58F50F"><b><font face = "Verdana">Welcome to our Blog</font></b></div>
 		</div><br>
 		<div class="row">
 			<div class="col-lg-3">
 				<div class="thumbnail">
 		    	<div class="caption">
 		    		<a href="https://youtu.be/0_YNQarABYc"><img src="img/you.jpg" style="height:150px; width:auto;"><br>
 		    		<button type="button" class="btn btn-primary">click here for vedio</button>
 		    		</a>
 		    		<h3>BCAA MOJITO</h3>
 		    		<ul style="color: white;">
 		    			<lh style="font-size: 25px;"><font face="Times New Roman">Ingredients</font></lh><hr>
 		    			<li>1 scoop ON BCAA, Fruit Punch</li><br>
 		    			<li>1 TBSP Water</li><br>
 		    			<li>120z Sparkling Water</li><br>
 		    			<li>1 tsp Lime juice</li><br>
 		    			<li>3 medium strawberries sliced</li><br>
 		    			<li>2 mint leaves</li>
 		    		</ul><br>
 		    		<h4 style="color: red;">Check our vedio for directions</h4>
 		    		
 		    	</div>
 		    	
 		    </div>
 		    </div>

 		    
 		    <div class="col-lg-3">
 		    <div class="thumbnail">
 		    	<div class="caption">
 		    		<a href="https://youtu.be/gz4DVP8Vjcg"><img src="img/you1.jpg"  style="height:150px; width:auto;"><br>
 		    		<button type="button" class="btn btn-primary">click here for vedio</button>
 		    		</a>
 		    		<h4>GOLD STANDARD 100% WHEY DOUBLE CHOCOLATE COOKIES</h4>
 		    		<ul style="color: white;">
 		    			<lh style="font-size: 25px;"><font face="Times New Roman">Ingredients</font></lh><hr>
 		    			<li>81g PB2</li><br>
 		    			<li>2 Tbsp Water</li><br>
 		    			<li>45g Low fat cream cheese</li><br>
 		    			<li>1 Egg</li>
 		  
 		    			<li>4g Stevia</li><br>
 		    			<li>10g Gold Standard 100% Whey</li><br>
 		    			<li>18g Cocoa Powder</li>
 		    			<li>4 Tbsp Chocolate Chips</li><br>
 		    		</ul><br><br>
 		    		<h4 style="color: red;">Check our vedio for directions</h4>
 		    	</div>
 		    </div>
 		    </div>
 		    <div class="col-lg-3">
 		    	<div class="thumbnail">
 		    		<div class="caption">
 		    			<a href="https://youtu.be/a3zgacL36V0"><img src="img/you2.jpg"  style="height:150px; width:auto;"><br>
 		    		<button type="button" class="btn btn-primary">click here for vedio</button>
 		    		</a>
 		    		<h3>MIXED BERRY AMINO ENERGY MOCKTAIL</h3>
 		    		<ul  style="color: white;">
 		    			<lh style="font-size: 25px;"><font face="Times New Roman">Ingredients</font></lh><hr>
 		    			<li>1/2 cup crushed ice</li>
 		    			<li>2 medium strawberries, mashed</li>
 		    			<li>1/4 cup fresh blueberries</li>
 		    			<li>1 can Amino Energy Sparkling, cherry</li>
 		    			<li>1/2 tsp. lemon juice</li>
 		    			<li>1 mint leaf</li>
 		    			
 		    		</ul><br><br>
                       <h4 style="color: red;">Check our vedio for directions</h4>
 		    	</div>
 		    </div>
 		</div>
 		    <div class="col-lg-3">
 		    	<div class="thumbnail">
 		    		<div class="caption">
 		    			<a href="https://youtu.be/PnNswb0kB1k"><img src="img/you3.jpg"  style="height:150px; width:auto;"><br>
 		    		<button type="button" class="btn btn-primary">click here for vedio</button></a>
 		    		<h3>CARAMEL COFFEE CREAM PIE</h3>
 		    		<ul  style="color: white;">
 		    			<lh style="font-size: 25px;"><font face="Times New Roman">Ingredients</font></lh><hr>
 		    			<li>5 ON Protein Wafers</li>
 		    			<li>120g plain greek yogurt</li>
 		    			<li>175g Lite Whipped Topping</li>
 		    			<li>8g instant coffee</li>
 		    			<li>10g sugar free vanilla pudding mix</li>
 		    			<li>2 TBSP (or 38g) Sugar Free Caramel Syrup</li>
 		    			
 		    		</ul><br><br>
                       <h4 style="color: red;">Check our vedio for directions</h4>
 		    		</div>
 		    	</div>
 		    	 
 		    </div>

 		</div><br><br>
      <!-- videos -->
      <p style="color: #21BEEA;text-align: center;"><font face="arial,helvetica" size="7"><b>VIDEOS</b></font></p>

      <div class="row" style="margin:0px 100px 0px 120px;">
      	<div class="col-lg-3">
      		<a href="https://www.optimumnutrition.com/en-us/videos/collagen-hyaluronic-acid"><img src="img/v1.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">COLLAGEN+HYALURONIC ACID</p><p>0:16</p></a>
      	</div>
      	<div class="col-lg-3"><a href="https://www.optimumnutrition.com/en-us/videos/essential-amino-energy-uc-ii-collagen"><img src="img/v2.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">ESSENTIAL AMINO ENERGY+ UC-II COLLAGEN</p><p>0:31</p></a>
      		</div>
      	<div class="col-lg-3">
      		<a href="https://www.optimumnutrition.com/en-us/videos/fit-40-meet-dr-cole"><img src="img/v3.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">FIT 40 MEET DR. COLE</p><p>0:27</p></a>
      	</div>
      	<div class="col-lg-3">
      		<a href="https://www.optimumnutrition.com/en-us/videos/protein-cake-bites-proven"><img src="img/v5.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">PROTEIN CAKE BITES|PROVEN</p><p>0:16</p></a>
      	</div>
      </div>
      <!-- neext row -->
      <div class="row" style="margin:0px 100px 0px 120px;">
      	<div class="col-lg-3">
      	<a href="https://www.optimumnutrition.com/en-us/videos/essential-amino-energy-electrolytes"><img src="img/v6.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">ESSENTIAL AMINO ENERGY+ ELECTROLYTES</p><p>0:16</p></a>	
      	</div>
      	<div class="col-lg-3">
      		<a href="https://www.optimumnutrition.com/en-us/videos/international-rugby-player-rob-kearney-true-strength"><img src="img/v7.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">INTERNATIONAL RUGBY PLAYER ROB KERNEY </p><p>1:45</p></a>
      	</div>
      	<div class="col-lg-3"><a href="https://www.youtube.com/watch?v=e1QLG7cy0nE"><img src="img/v8.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">JAY CUTTLER SUPPLEMENTS </p><p>7:45</p></a>
      		</div>
      	<div class="col-lg-3">
      		<a href="https://www.youtube.com/watch?v=89e518dl4I8"><img src="img/v9.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">TRAIN CHEST WITH ATHLEAN-X </p><p>7:51</p></a>
      	</div>
      </div>

      <!-- next row -->
      <div class="row" style="margin:0px 100px 0px 120px;">
      	<div class="col-lg-3">
      		<a href="https://www.youtube.com/watch?v=8VgtFxu3Iw4"><img src="img/v10.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">TRAIN BACK WITH ANDREI DEIU </p><p>3:48</p></a>
      	</div>
      	<div class="col-lg-3">
      		<a href="https://www.youtube.com/watch?v=0M8dDZv4f94"><img src="img/v11.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">TRAIN BICEP WITH ANDREI DEIU </p><p>3:15</p></a>
      	</div>
      	<div class="col-lg-3">
      		<a href="https://www.youtube.com/watch?v=DhHIV6hKIYU"><img src="img/v12.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">TRAIN LEGS WITH BIG RAMMY </p><p>4:33</p></a>
      	</div>
      	<div class="col-lg-3">
      		<a href="https://www.youtube.com/watch?v=f7wxcN6uAYE&t=917s"><img src="img/v13.jpg" style="border: 1px solid white;width: 250px;height: 150px"><br>
      			<p style="color: red">TRAIN SHOULDER WITH BIG RAMMY|4 MUST DO </p><p>17:24</p></a>
      	</div>
      </div>
<?php require'footer.html' ?>
 	</div>
 
 </body>
 </html>