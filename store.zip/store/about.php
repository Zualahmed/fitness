<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title> About page</title>
</head>
<body>

	<div class="container-fluid" style="background: #A6E777">
	
<?php 
require'navbar.php'
 ?>
 <div class="row">
 	<div class="col-lg-6" style="background:#DFE0E2; text-align: center;padding: 50px 50px 50px 50px">
 		<h1>Hello!</h1><br>
 		<h3>We're fitnessworld- a great place for people serious about health and fitness.</h3><br>
 		<p>We're a young start-up  that work for your needs in fitness and well-being. We deliver everything from genuine protein supplements to vitamins smoothly at honest prices.</p>
 	</div>
 	<div class="col-lg-6" style="padding: 50px 0px 0px 200px" >
 		<img src="img/a1.jpg"><br>
 		<img src="img/a2.jpg">
 		<img src="img/a3.jpg">
 		<img src="img/a4.jpg">
 		<img src="img/a5.jpg">
 	</div>
 </div>	

 <div class="row">
 	<div class="col-lg-6">
 		
 			<div class="caption" style="text-align: center;">
 				<img src="img/auth_new.gif"style="padding-top:50px">
 				<h2><b>AUTHENTICITY <br>GURANTEED</b></h2>
 			</div>
 		</div>
 	
 	<div class="col-lg-6" style="background:#DFE0E2; text-align: center;padding: 50px 50px 50px 50px">
 		<h3>We do what's right by you. We value authenticity over everything else.</h3>
 		<p>We sell consumables that you need rather than want. In such cases, the authenticity of the product matters. Half the supplement market is flooded with fakes pumped with steroids. And that's why when you shop whey from us, be sure it is 100% genuine, without any junk.</p><br>
 		<p>Whenever you see this logo next to our product, it's just our way of telling you that we've sourced the product directly and test it before sending it out to you. It is to tell you that what you are having is safe.</p>
 	</div>
 </div>	

<div class="row">
	<div class="col-lg-6" style="background:#DFE0E2; text-align: center;padding: 50px 50px 50px 50px">
		<h3>Good health delivered to your doorstep, every time</h3><br>
		<p>You no longer have to hunt for your supplements or a ton of nutrition stores to find the supplement you need. We have over 200 brands & authorized vendors listed on our website. All just to make sure what you get is right</p>
	</div>
	<div class="col-lg-6" style="text-align: center;">
		<img src="img/on.jpg"><br>
		<img src="img/isopure.jpg">
		<img src="img/ronieCole.jpg">
		<img src="img/muscleTech.jpg">
		<img src="img/dymatize.jpg">
	</div>
</div>
<div class="row">
	<div class="col-lg-6" style="text-align: center;padding: 100px 50px 50px 100px">
		<img src="img/a6.jpg">
	</div>
	<div class="col-lg-6" style="background:#DFE0E2; text-align: center;padding: 100px 50px 100px 70px">
		<h3>How it came together?</h3><br>
		<p>We worked really hard to get here. We enjoy doing things fast, failing quickly and putting all that we learnt in our next idea. Our team has people from premier institutes around the world, but we're proud to say that we learnt most when we were on the job.</p>
	</div>
</div>
<?php require'footer.html' ?>
	</div>


</body>
</html> 