<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>vitamins</title>
</head>
<body>

<div class="container-fluid">

  <div class="row">
	<div class="col-lg-12" style="border-bottom: 1px solid black; text-align: center; font-size: 40px;font-style: bold; color: #10AA10"><font face = "Times New Roman">Vitamins Products</font></div>
  </div>

  <div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/vitamin1.jpg">
				<h4>Healthkart multivitamin with multi mineral- 600mg</h4>
				<h4 style="font-style: bold; color:solid black">MRP-459</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/vitamin2.jpg">
				<h4>Health fishoil 1000mg with180 mg EPA and 120mg DHA</h4>
				<h4 style="font-style: bold; color:solid black">MRP-339</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/vitamin3.jpg">
				<h4>Now Omega-3, 100 softgels</h4>	
				<h4 style="font-style: bold; color:solid black">MRP-799</h4>
				<button type="button" class="btn btn-primary">Buy</button>
		</div>
	</div>
</div>
</div>
<div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/vitamin4.jpg">
				<h4>Muscletech platinum 100% fish oil -90 tablet</h4>
				<h4 style="font-style: bold; color:solid black">MRP-1044</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/vitamin5.jpg">
				<h4>MuscleBlaze Fish oil gold(460 EPA & 380 DHA)-90 capsules</h4>
				<h4 style="font-style: bold; color:solid black">MRP-855</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/vitamin6.jpg">
				<h4>Muscletech platinum 100% L-Arginine - 100capsules<br></h4>
				<h4 style="font-style: bold; color:solid black">MRP-1650</h4>
				<button type="button" class=" btn btn-primary">Buy</button>	
		</div>
	</div>
</div>
</div>
<div style="float: right;">
	<a href="vitamins.php"> <button  type="button" class="btn btn-danger">Show More</button></a>
</div>


</div>



</body>
</html>