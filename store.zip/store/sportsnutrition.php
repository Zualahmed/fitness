<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>sports products</title>
	
</head>
<body>
<div class="container-fluid">
<div class="row">
	<div class="col-lg-12" style="border-bottom: 1px solid black; text-align: center; font-size: 40px;font-style: bold;color: #E45512"><font face = "Times New Roman">Sports Products</font></div>
</div>

<div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/sports1.jpg">
				<h4>MuscleTech NitroTech perfomance series- 4lb milk chocolate</h4>
				<h4 style="font-style: bold; color:solid black">MRP-4595</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/sports2.jpg">
				<h4>Dymatize Elite 100% whey protien- 5lb rich chocolate</h4>
				<h4 style="font-style: bold; color:solid black">MRP-5500</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/sports3.jpg">
				<h4>MuscleBlze 100% whey protien- 5lb rich oreo</h4>	
				<h4 style="font-style: bold; color:solid black">MRP-4399</h4>
				<button type="button" class="btn btn-primary">Buy</button>
		</div>
	</div>
</div>
</div>

<div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/sports4.jpg">
				<h4>MuscleBlaze BCAA pro- 0.99lb pineapple</h4>
				<h4 style="font-style: bold; color:solid black">MRP-1434</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/sports5.jpg">
				<h4>Dymatize BCAA complex 5050 -0,66lb  unflavoured</h4>
				<h4 style="font-style: bold; color:solid black">MRP-1334</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/sports6.jpg">
				<h4>Ultimte NUtrition BCAA powder - 1lb fruit punch</h4>	
				<h4 style="font-style: bold; color:solid black">MRP-2149</h4>
				<button type="button" class="btn btn-primary">Buy</button>
		</div>
	</div>
</div>
</div>

<div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/sports7.jpg">
				<h4>MuscleBlaze high protien bar(30g protien- 6pics almond</h4>
				<h4 style="font-style: bold; color:solid black">MRP-790</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/sports8.jpg">
				<h4>MuscleTech neurocore- 0.48 lb fruit punch</h4>
				<h4 style="font-style: bold; color:solid black">MRP-2239</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/sports9.jpg">
				<h4>Cellucor C4 explosive preworkout- 0.85 lb fruit punch</h4>	
				<h4 style="font-style: bold; color:solid black">MRP-3473</h4>
				<button type="button" class="btn btn-primary">Buy</button>
		</div>
	</div>
	
<div style="float: right;">
	<a href="sportsnutrition.php"> <button  type="button" class="btn btn-danger">Show More</button></a>
</div>
</div>

</div>
</div>
</body>
</html>