<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>Ayurvedic products</title>
</head>
<body>
<div class="container-fluid">
<div class="row">
	<div class="col-lg-12" style="border-bottom: 1px solid black; text-align: center; font-size: 40px;font-style: bold; color: #6F084B"><font face = "Times New Roman">Ayurvedic Products</font></div>
</div>
<div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/ayur1.jpg">
				<h4>Truebasics ashwagandha- 600mg</h4>
				<h4 style="font-style: bold; color:solid black">MRP-849</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/ayur2.jpg">
				<h4>Inlife digestive enzymes-60 capsules</h4>
				<h4 style="font-style: bold; color:solid black">MRP-639</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/ayur3.jpg">
				<h4>Morpheme remedies green cofee bean-60 capsules</h4>	
				<h4 style="font-style: bold; color:solid black">MRP-399</h4>
				<button type="button" class="btn btn-primary">Buy</button>
		</div>
	</div>
</div>
</div>
<div class="row">
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/ayur4.jpg">
				<h4>Truebasics Liver deto with silybin milk thistle extract -90 tablet</h4>
				<h4 style="font-style: bold; color:solid black">MRP-1344</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<img src="img/ayur5.jpg">
				<h4>Biotrex Green Tea(500mg) -60 capsules unflavoured</h4>
				<h4 style="font-style: bold; color:solid black">MRP-855</h4>
				<button type="button" class="btn btn-primary">Buy</button>
			</div>
		</div>
	</div>
	<div class="col-lg-4">
	<div class="thumbnail">
		<div class="caption">
		<img src="img/ayur6.jpg">
				<h4>Natures velvet Shilajit pure extract(500mg)- 60 capsules<br></h4>
				<h4 style="font-style: bold; color:solid black">MRP-650</h4>
				<button type="button" class="btn btn-primary">Buy</button>
		</div>
	</div>
</div>
</div>

<div style="float: right;">
	<a href="ayurvedic.php"> <button  type="button" class="btn btn-danger">Show More</button></a>
</div>
</div>
</body>
</html>