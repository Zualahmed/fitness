<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	 	<meta charset="utf-8">
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" type="text/css" href="stylesheet.css">
 	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 	
	<title>nav bar</title>
</head>
<body>


<div class="row">
 	<div class="col-lg-12">

 <nav>  
 			
 			<ul> 
 			     


 				
 				
                <div style="float: right;"> 
 				<?php 
                
                if (isset($_SESSION['userUid'])) {
	            echo '<form action="logout.inc.php" method="POST" style="display:inline-block;">
 					<button type="submit" name="logout-submit">LOGOUT</button>
 				</form>';
                 }
                else
                 {
	           echo '<form action="login.inc.php" method="POST" >
 					<input type="text" name="mailuid" placeholder="Username">
 					<input type="password" name="pwd" placeholder="Password">
 					<button type="submit" name="login-submit">LOGIN</button>
 				</form>
 			      <a href="signup.php">SIGNUP</a>';
                  }
 				 ?>
 				 </div>
 
 			</ul>
 			
</nav>
    </div>
 </div>
 </body>
</html>