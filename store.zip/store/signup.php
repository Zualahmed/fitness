<?php 
require 'navbar.php';
 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
 <head>
 	<meta charset="utf-8"> 
 	<title>Signup Page</title>
 	<link rel="stylesheet"  href="style.css">
 	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
 	<meta name="discription" content="find the best product out here and or get your self certified and be a good learner">
 	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 </head>
 <body>
 	
 	
 	

 	<section>
 		<h1 style="color:white;text-align:center;">SIGNUP PAGE</h1>


 
    <div class="row">
    	<div class="col-lg-4">
    		<div class="panel panel-primary">
					<div class="panel-heading">User Registration</div>
					<div class="panel-body">
						<form action="signup.inc.php" method="POST">
							<div class="form-group">
								<label for="username">Username</label>
								<input type="text" class="form-control"  name="uid" placeholder="username">
							</div>
							
							<div class="form-group">
								<label for="email">E-mail</label>
								<input type="email" class="form-control"  name="mail" placeholder="E-mail">
							</div>
							<div class="form-group">
								<label for="password">Password</label>
								<input type="password" class="form-control"  name="pwd" placeholder="Password">
							</div>
							<div class="form-group">
								<label for="password">Repeat password</label>
								<input type="password" class="form-control"  name="pwd-repeat" placeholder="Repet password">
							</div>
							<button type="submit" class="btn btn-primary" name="signup-submit">Signup</button>
								
							</button>
			
						</form>
					</div>
				</div>
    		
    	</div>
    </div>
   
 		
 	</section>
 
 </body>
 </html>